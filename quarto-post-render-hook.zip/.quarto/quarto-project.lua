-- .quarto/quarto-project.lua
-- This hook restores the CNAME file after rendering the site

function post_render()
  os.execute("cp CNAME docs/CNAME")
end
